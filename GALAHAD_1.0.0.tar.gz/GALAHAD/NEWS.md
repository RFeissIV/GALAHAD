# GALAHAD 1.0.0

## Initial CRAN Release

* First public release of GALAHAD optimizer
* Implements geometry-adaptive optimization with Lyapunov stability guarantees
* Supports mixed parameter geometries: log-scaled (T), positive-only (P), and Euclidean (E)
* Features trust-region projection, adaptive step-size control, and Halpern averaging
* Designed for biological modeling applications (germination, dose-response, survival curves)
* Includes comprehensive documentation and examples
* Developed at Minnesota Center for Prion Research and Outreach (MNPRO), University of Minnesota
